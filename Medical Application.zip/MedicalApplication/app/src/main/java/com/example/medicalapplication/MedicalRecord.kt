package com.example.medicalapplication

data class MedicalRecord(
    val recordName: String = "",
    val dateOfCreation: String = "",
    val recordType: String = "",

)