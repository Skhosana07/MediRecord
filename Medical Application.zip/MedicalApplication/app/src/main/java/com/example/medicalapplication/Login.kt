package com.example.medicalapplication

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Spannable
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


@Suppress("DEPRECATION")
class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        val registerNav: TextView = findViewById(R.id.registerNav)


        val spannableString = SpannableString("New user? Register")
        spannableString.setSpan(ForegroundColorSpan(Color.parseColor("#1A92ED")), 10, 18, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        spannableString.setSpan(StyleSpan(Typeface.BOLD), 10, 18, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        registerNav.text = spannableString

        registerNav.setOnClickListener {
            val intent = Intent(this, Register::class.java)
            startActivity(intent)
        }



    }
}