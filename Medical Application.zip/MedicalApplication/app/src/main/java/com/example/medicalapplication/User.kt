package com.example.medicalapplication

data class User(

val email: String = "",
val username: String = ""


)
