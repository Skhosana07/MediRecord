package com.example.medicalapplication

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.DatePicker
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.Firebase
import java.io.InputStream
import java.util.Calendar


@Suppress("DEPRECATION")
class AddMed : AppCompatActivity() {

    private lateinit var dateCreationInput: TextInputEditText
    private lateinit var recordNameInput: TextInputEditText
    private lateinit var saveRecordButton: Button
    private lateinit var recordSpinner: Spinner
    private val PICK_IMAGE_REQUEST = 1
    private lateinit var addPictureCard: CardView
    private lateinit var imageContainer: LinearLayout
    private var selectedImages: MutableList<ImageView> = mutableListOf()

   // private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_med)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )



        recordSpinner = findViewById(R.id.spinner_record_type)
        recordNameInput = findViewById(R.id.edit_record_name)
        dateCreationInput = findViewById(R.id.edit_date_creation)
        saveRecordButton = findViewById(R.id.button_save_record)


        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.record_array,
            android.R.layout.simple_spinner_item
        )

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        recordSpinner.adapter = adapter

        // Initialize views
        addPictureCard = findViewById(R.id.card_add_picture)
        imageContainer = findViewById(R.id.image_container)

        // Set click listener for the card to open gallery
        addPictureCard.setOnClickListener {
            openGallery()
        }



        dateCreationInput.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(
                this,
                { _: DatePicker, selectedYear: Int, selectedMonth: Int, selectedDay: Int ->
                    val date = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                    dateCreationInput.setText(date)
                },
                year, month, day
            )
            datePickerDialog.show()
        }

        saveRecordButton.setOnClickListener {
        }


    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { imageUri ->
                addImageToContainer(imageUri)
            }
        }
    }

    private fun addImageToContainer(imageUri: Uri) {
        val imageView = ImageView(this)
        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(8, 8, 8, 8)
        imageView.layoutParams = layoutParams
        imageView.adjustViewBounds = true
        imageView.setOnClickListener { /* Handle image click */ }

        // Load the image and add it to the container
        val inputStream: InputStream? = contentResolver.openInputStream(imageUri)
        val bitmap = BitmapFactory.decodeStream(inputStream)
        imageView.setImageBitmap(bitmap)
        imageContainer.addView(imageView)

        // Store the ImageView if needed
        selectedImages.add(imageView)
    }
    
}